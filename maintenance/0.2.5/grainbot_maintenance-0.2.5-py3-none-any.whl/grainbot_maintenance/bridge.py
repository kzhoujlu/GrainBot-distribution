"""Local JSON bridge for native UI. Does not bypass the web service authentication."""
import argparse
import json
from pathlib import Path
import sys
import os
import contextlib
import io
from .updates import ComponentUpdates
from .inventory import collect


def execute(request, workspace, installation, assets=None):
    manager = ComponentUpdates(workspace)
    action = request["action"]
    component, version = request.get("component"), request.get("version")
    if action == "inventory":
        return collect(manager, installation, assets)
    if action == "inspect_source":
        from .source_discovery import inspect_source
        return inspect_source(request["url"], workspace)
    if action.startswith("application_"):
        from .application_updates import ApplicationUpdates
        updates = ApplicationUpdates(installation)
        operation = action[len("application_"):]
        if operation == "source":
            return updates.source(request["url"])
        if operation not in {"check", "download", "install", "rollback"}:
            raise ValueError("Unsupported application update operation")
        with contextlib.redirect_stdout(io.StringIO()):
            return getattr(updates, operation)()
    if action == "libraries":
        from .third_party import libraries
        return libraries(os.environ.get("GRAINBOT_RUNTIME_PYTHON", sys.executable))
    if action.startswith("builtin_"):
        from . import third_party
        operation = action[len("builtin_"):]
        if operation == "check":return third_party.check(manager, component)
        if operation in {"download", "resources"}:
            record = third_party.download(manager, component)
            return {"component": component, "version": record["manifest"]["version"], "status": record["status"]}
        if operation == "install":return third_party.install(manager, component, os.environ.get("GRAINBOT_RUNTIME_PYTHON", sys.executable))
        if operation == "disable":return manager.disable(component)
        if operation == "rollback":return manager.rollback(component)
        if operation == "validate":
            record = third_party.download(manager, component)
            manager._verify_record(record)
            return {"status": "verified", "scientific_evaluation": False}
        raise ValueError("Unsupported official model operation")
    if action == "source":
        manager.source(component, request.get("repository", ""), request.get("public_key", ""), request["kind"])
        return {"saved": True}
    if action == "check":
        return manager.check(component)
    if action == "download":
        record = manager.download(component)
    elif action == "import":
        manifest = Path(request["manifest"])
        data = json.loads(manifest.read_text(encoding="utf-8"))
        signature = manifest.with_name(component+".manifest.sig")
        record = manager.stage(component, manifest, signature if signature.is_file() else None, manifest.parent / data["archive"])
    elif action == "resources":
        return manager.prepare_resources(component, version)
    elif action in {"validate", "install"}:
        selected = manager.status()["staged"].get(component+":"+version)
        if not selected:
            raise ValueError("Download this version first")
        if selected["manifest"]["kind"] == "model":
            # Installation checks the signed adapter contract and resources, not scientific quality.
            manager._verify_record(selected)
            manager._contract(selected["manifest"], Path(selected["path"]))
            report = {"validation": "signed files, resources and adapter entrypoint", "scientific_evaluation": False}
        else:
            record = manager.test(component, version)
            if record["status"] != "tested":
                raise ValueError("Compatibility validation failed: "+record.get("trial", {}).get("stderr", ""))
            report = record.get("trial", {})
        if action == "validate":
            return report
        return manager.enable(component, version)
    elif action == "disable":
        return manager.disable(component)
    elif action == "image":
        image = Path(request["image"])
        if image.stat().st_size > 20*1024**2:
            raise ValueError("Trial image must be under 20 MB")
        return manager.save_trial_image(component, version, image.read_bytes())
    elif action == "test":
        selected = manager.status()["staged"].get(component+":"+version)
        if selected and selected["manifest"]["kind"] == "model" and not selected.get("trial_image"):
            raise ValueError("Choose a real trial image before reviewing a model version")
        record = manager.test(component, version)
    elif action == "activate":
        return manager.activate(component, version, request["decision"])
    elif action == "review":
        return manager.review(component, version, request["decision"])
    elif action == "rollback":
        return manager.rollback(component)
    elif action == "preview":
        record = manager.status()["staged"][component+":"+version]
        folder = Path(record["path"])
        images = []
        if record.get("trial_image"):
            images.append(record["trial_image"])
        if record["manifest"]["kind"] == "dataset" and not record.get("trial", {}).get("artifacts"):
            data = json.loads((folder / "payload/dataset.json").read_text(encoding="utf-8"))
            for sample in data["samples"][:5]:
                path = (folder / "payload" / sample["image"]["path"]).resolve()
                if path.is_relative_to((folder / "payload").resolve()):
                    images.append(str(path))
        else:
            images.extend(str(folder / "trial-results" / name) for name in record.get("trial", {}).get("artifacts", []) if Path(name).name == name and Path(name).suffix.lower() in {".png", ".jpg", ".jpeg"})
        return {"images": images}
    else:
        raise ValueError("Unsupported local management operation")
    return {"component": record["manifest"]["component"], "version": record["manifest"]["version"], "status": record["status"], "review": record["review"], "trial": record.get("trial")}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--installation", type=Path, required=True)
    parser.add_argument("--assets", type=Path)
    args = parser.parse_args()
    try:
        request = json.loads(sys.stdin.read(65537))
        result = execute(request, args.workspace, args.installation, args.assets)
        print(json.dumps({"ok": True, "result": result}))
        return 0
    except Exception as error:
        print(json.dumps({"ok": False, "error": str(error) or type(error).__name__}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
