"""Resolve versioned Git metadata without exposing it as release downloads."""
import hashlib
import json
from pathlib import Path
import re

MARKER = re.compile(r"<!-- grainbot-metadata: ([a-f0-9]{40}); index-sha256: ([a-f0-9]{64}) -->")


def release_files(release, repository, directory):
    from .updates import github_download, identifier
    from .github_source import REPOSITORY
    if not REPOSITORY.fullmatch(repository):
        raise ValueError("Invalid metadata repository")
    assets = {item["name"]: item["browser_download_url"] for item in release.get("assets", [])}
    marker = MARKER.search(release.get("body") or "")
    if not marker:
        return {"assets": assets, "hashes": {}, "revision": None}
    revision, expected = marker.groups()
    tag = identifier(release["tag_name"])
    base = f"https://raw.githubusercontent.com/{repository}/{revision}/metadata/{tag}/"
    file = Path(directory)/"metadata-index.json"
    github_download(base+"index.json", file, 4*1024**2)
    if hashlib.sha256(file.read_bytes()).hexdigest() != expected:
        raise ValueError("Release metadata index SHA256 mismatch")
    index = json.loads(file.read_text(encoding="utf-8"))
    if index.get("schema_version") != 1 or index.get("release_tag") != tag:
        raise ValueError("Release metadata index does not match its release")
    components = index.get("components", [])
    if not components or len(components) > 1000:
        raise ValueError("Invalid release metadata component inventory")
    hashes = {}
    for item in components:
        component = identifier(item["component"])
        if item["kind"] not in {"model", "dataset", "frontend", "backend"}:
            raise ValueError("Invalid metadata component kind")
        identifier(item["version"])
        for suffix in ("manifest.json", "manifest.sig"):
            name = component+"."+suffix
            digest = item.get("files", {}).get(name)
            if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
                raise ValueError("Metadata files must declare SHA256")
            if name in hashes:
                raise ValueError("Duplicate metadata component")
            assets[name] = base+name
            hashes[name] = digest
    return {"assets": assets, "hashes": hashes, "revision": revision}
