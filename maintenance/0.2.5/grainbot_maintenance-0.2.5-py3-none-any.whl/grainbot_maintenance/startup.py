"""Per-launch desktop readiness, independent of scientific imports."""
import json
import os
from pathlib import Path
import threading
import time
from uuid import uuid4

_lock = threading.Lock()
_closed = False


def report(stage, detail=""):
    global _closed
    target = os.environ.get("GRAINBOT_STARTUP_STATUS")
    if not target:
        return
    path = Path(target)
    with _lock:
        if _closed:
            return
        if stage == "closed":
            _closed = True
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name+"."+uuid4().hex+".tmp")
        temporary.write_text(json.dumps({"stage": stage, "detail": detail, "pid": os.getpid(), "timestamp": time.time()}), encoding="utf-8")
        os.replace(temporary, path)


def page_ready(window, origin, *, timeout=120):
    """A loaded browser document is ready only once the application has rendered."""
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        current = window.get_current_url() or ""
        if current.rstrip("/") != origin.rstrip("/"):
            report("failed", "Studio page did not load from its local server")
            return
        if window.events.closed.is_set():
            report("closed")
            return
        if window.events.shown.is_set() and window.evaluate_js("Boolean(document.getElementById('root') && document.getElementById('root').childElementCount)"):
            report("ready")
            return
        time.sleep(0.1)
    report("failed", "Studio page did not finish rendering; check desktop.log")
