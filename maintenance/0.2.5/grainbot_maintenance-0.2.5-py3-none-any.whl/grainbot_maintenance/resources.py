"""Pinned external resources. Model implementations and weights stay outside core code."""
import os
from pathlib import Path
import re
import shutil
from urllib.parse import quote, urlsplit
import urllib.request
from .integrity import sha256 as digest


def validate(resource):
    if not re.fullmatch(r"[a-f0-9]{64}", resource.get("sha256", "")):
        raise ValueError("External resources require SHA256")
    source = resource["source"]
    if source["provider"] not in {"github", "github_release", "huggingface"}:
        raise ValueError("Unsupported resource provider")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", source["repository"]):
        raise ValueError("Repository must be owner/name")
    if source["provider"] == "github_release":
        if source["revision"].lower() in {"latest", "main", "master"} or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}", source["revision"]):
            raise ValueError("Release resources must pin a fixed release tag")
        if "/" in source["filename"]:
            raise ValueError("Release asset filename must be a basename")
    elif not re.fullmatch(r"[a-f0-9]{40}", source["revision"]):
        raise ValueError("Resources must pin a full immutable commit")
    for value in [resource["target"], source["filename"]]:
        parts = value.split("/")
        reserved = {"CON", "PRN", "AUX", "NUL"} | {f"{prefix}{i}" for prefix in ("COM", "LPT") for i in range(1, 10)}
        if not value or "\\" in value or any(
            part in {"", ".", ".."} or part.endswith((".", " "))
            or re.search(r'[\x00-\x1f:<>"|?*]', part)
            or part.split(".")[0].upper() in reserved for part in parts
        ):
            raise ValueError("Unsafe resource path")
    if not resource.get("license"):
        raise ValueError("External resource license attribution is required")


def download(resource, destination):
    validate(resource)
    source=resource["source"]
    if source["provider"] == "github_release":
        from .updates import github_download
        url = "https://github.com/"+source["repository"]+"/releases/download/"+quote(source["revision"], safe="")+"/"+quote(source["filename"], safe="")
        github_download(url, destination, 16*1024**3)
        return
    prefix = "https://raw.githubusercontent.com/" if source["provider"] == "github" else "https://huggingface.co/"
    middle = "/" if source["provider"] == "github" else "/resolve/"
    url = prefix + source["repository"] + middle + source["revision"] + "/" + quote(source["filename"], safe="/")
    class Redirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, message, headers, target):
            parsed=urlsplit(target)
            if parsed.scheme!="https" or parsed.username or not (parsed.hostname in {"raw.githubusercontent.com","huggingface.co"} or parsed.hostname.endswith(".hf.co") or parsed.hostname.endswith(".huggingface.co")):
                raise ValueError("Unexpected resource redirect host")
            return super().redirect_request(request,fp,code,message,headers,target)
    with urllib.request.build_opener(Redirect()).open(url, timeout=60) as response, destination.open("wb") as output:
        total=0
        while data:=response.read(1024**2):
            total+=len(data)
            if total>16*1024**3:
                raise ValueError("External resource too large")
            output.write(data)


def prepare(manifest, folder, cache):
    folder=Path(folder).resolve();cache=Path(cache).resolve();cache.mkdir(parents=True,exist_ok=True)
    for resource in manifest.get("resources", []):
        validate(resource)
        target=(folder/resource["target"]).resolve()
        if not target.is_relative_to(folder):
            raise ValueError("External resource escapes package")
        blob=cache/resource["sha256"]
        if not blob.is_file() or digest(blob)!=resource["sha256"]:
            partial=blob.with_suffix(".partial")
            try:
                download(resource,partial)
                if digest(partial)!=resource["sha256"]:
                    raise ValueError("External resource hash mismatch")
                os.replace(partial,blob)
            finally:
                partial.unlink(missing_ok=True)
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.is_file() and digest(target)==resource["sha256"]:
            continue
        target.unlink(missing_ok=True)
        try:
            os.link(blob,target)
        except OSError:
            shutil.copy2(blob,target)
    return {"status":"resources_ready", "count":len(manifest.get("resources",[]))}


def verify(manifest,folder):
    for resource in manifest.get("resources",[]):
        validate(resource)
        path=(Path(folder)/resource["target"]).resolve()
        if not path.is_relative_to(Path(folder).resolve()) or not path.is_file() or digest(path)!=resource["sha256"]:
            raise ValueError("External resource missing or changed; download required resources first")
