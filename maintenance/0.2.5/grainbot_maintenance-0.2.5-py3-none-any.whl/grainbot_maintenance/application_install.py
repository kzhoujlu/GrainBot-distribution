"""Install a pinned published application into its own normal Python environment.

This bootstrap release is separate from signed component updates. The native
control environment never installs these application wheels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
from uuid import uuid4
import zipfile

from .integrity import sha256
from .updates import atomic_json, github_download, identifier, REPO

REPOSITORY = "kzhoujlu/GrainBot-distribution"
TAG = "2026.10.14.post2"
ROLES = {"maintenance", "backend", "matmorph", "frontend"}
NAMESPACES = {"maintenance": "grainbot_maintenance", "backend": "grainbot_studio", "matmorph": "matmorph"}
PREFIXES = {"maintenance": "grainbot_maintenance-", "backend": "grainbot_studio_app-", "matmorph": "matmorph-", "frontend": "grainbot_frontend-"}


def validate_release(data):
    if not isinstance(data, dict):
        raise ValueError("Unrecognized application release source")
    repository, tag = data.get("repository", ""), data.get("tag", "")
    if data.get("schema_version") != 1 or not isinstance(repository, str) or not REPO.fullmatch(repository):
        raise ValueError("Unrecognized application release source")
    identifier(tag)
    if any(part in {".", ".."} for part in repository.split("/")):
        raise ValueError("Unsafe application repository")
    prefix = f"https://github.com/{repository}/releases/download/{tag}/"
    if data.get("release_url") != f"https://github.com/{repository}/releases/tag/{tag}":
        raise ValueError("Unexpected release source")
    assets = data.get("assets", [])
    if not isinstance(assets, list) or len(assets) != 4 or any(not isinstance(a, dict) for a in assets) or {a.get("role") for a in assets} != ROLES:
        raise ValueError("Application release requires exactly four assets")
    for asset in data["assets"]:
        name, role = asset.get("name"), asset["role"]
        if not isinstance(name, str) or not name or "/" in name or "\\" in name or ":" in name or asset.get("download_url") != prefix + name:
            raise ValueError("Unexpected release asset path or source")
        if not name.startswith(PREFIXES[role]) or not name.endswith(".zip" if role == "frontend" else "-py3-none-any.whl"):
            raise ValueError("Unsupported published application asset format")
        if role in NAMESPACES and asset.get("namespace") != NAMESPACES[role]:
            raise ValueError("Unexpected application package namespace")
        digest = asset.get("sha256", "")
        if type(asset.get("bytes")) is not int or not 0 < asset["bytes"] <= 128 * 1024**2 or not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("Invalid published asset identity")
    return data


def _release_directory(root, category, release):
    base = root / category
    if release["repository"] != REPOSITORY:
        base = base.joinpath(*release["repository"].split("/"))
    return base / release["tag"]


def catalog():
    data = json.loads(Path(__file__).with_name("published_release.json").read_text(encoding="utf-8"))
    prefix = f"https://github.com/{REPOSITORY}/releases/download/{TAG}/"
    if data.get("schema_version") != 1 or data.get("repository") != REPOSITORY or data.get("tag") != TAG:
        raise ValueError("Unrecognized built-in application release")
    if data.get("release_url") != f"https://github.com/{REPOSITORY}/releases/tag/{TAG}":
        raise ValueError("Unexpected release source")
    if len(data.get("assets", [])) != 4 or {a.get("role") for a in data["assets"]} != ROLES:
        raise ValueError("Application release requires exactly four assets")
    for asset in data["assets"]:
        name = asset["name"]
        if not name or "/" in name or "\\" in name or ":" in name or asset["download_url"] != prefix + name:
            raise ValueError("Unexpected release asset path or source")
        if not isinstance(asset["bytes"], int) or asset["bytes"] <= 0 or len(asset["sha256"]) != 64:
            raise ValueError("Invalid built-in asset identity")
    return validate_release(data)


def _runtime(root, python, release=None):
    python = Path(python).resolve()
    for profile in ("cpu", "cuda128"):
        expected = root / "environments" / profile / "Scripts" / "python.exe"
        purelib = root / "environments" / profile / "Lib" / "site-packages"
        if python == expected and expected.resolve() == expected and purelib.resolve() == purelib and expected.is_file():
            return profile, expected, purelib
    expected = root / "runtime" / "python.exe"
    if release and python == expected and expected.resolve() == expected and expected.is_file():
        purelib = _release_directory(root, "applications", release) / "backend"
        if purelib.resolve() != purelib:
            raise ValueError("Portable application directory redirects outside installation")
        return "portable", expected, purelib
    raise ValueError("Application Python must belong to this installation's CPU or CUDA environment")


def _cache(root, release, download=False):
    validate_release(release)
    directory = _release_directory(root, "packages/published", release)
    if not directory.resolve().is_relative_to(root):
        raise ValueError("Application cache escapes installation")
    if download:
        directory.mkdir(parents=True, exist_ok=True)
    paths = {}
    for asset in release["assets"]:
        path = directory / asset["name"]
        if not path.resolve().is_relative_to(root):
            raise ValueError("Cached application asset escapes installation")
        valid = path.is_file() and path.stat().st_size == asset["bytes"] and sha256(path) == asset["sha256"]
        if not valid and download:
            temporary = path.with_name(path.name + "." + uuid4().hex + ".partial")
            try:
                github_download(asset["download_url"], temporary, asset["bytes"])
                if temporary.stat().st_size != asset["bytes"] or sha256(temporary) != asset["sha256"]:
                    raise ValueError("Published application asset size or SHA256 mismatch")
                os.replace(temporary, path)
                valid = True
            finally:
                temporary.unlink(missing_ok=True)
        if not valid:
            raise ValueError("Published application cache is missing or changed")
        paths[asset["role"]] = path
    return paths


def _members(archive):
    members, names, total = [], set(), 0
    for member in archive.infolist():
        name = member.filename
        if member.orig_filename != name:
            raise ValueError("Unsafe published archive path")
        parts = PurePosixPath(name).parts
        reserved = {"CON", "PRN", "AUX", "NUL"} | {f"{prefix}{i}" for prefix in ("COM", "LPT") for i in range(1, 10)}
        if not parts or name.startswith("/") or "\\" in name or any(
            part in {".", ".."} or any(c in part for c in ':<>"|?*') or any(ord(c) < 32 for c in part)
            or part.endswith((".", " ")) or part.split(".")[0].upper() in reserved for part in parts
        ) or (member.external_attr >> 16) & 0o170000 == 0o120000:
            raise ValueError("Unsafe published archive path")
        key = name.rstrip("/").casefold()
        if key in names:
            raise ValueError("Duplicate published archive path")
        names.add(key)
        if not member.is_dir():
            total += member.file_size
            if total > 128 * 1024**2:
                raise ValueError("Published archive is too large")
            members.append(member)
    return members


def _extract_frontend(source, destination, root):
    if destination.resolve() != destination or not destination.resolve().is_relative_to(root):
        raise ValueError("Frontend path escapes installation")
    with zipfile.ZipFile(source) as archive:
        members = _members(archive)
        if not any(member.filename == "index.html" for member in members):
            raise ValueError("Published frontend is missing index.html")
        targets = []
        for member in members:
            target = destination / member.filename
            if not target.resolve().is_relative_to(destination.resolve()):
                raise ValueError("Frontend member escapes application directory")
            targets.append((member, target))
        for member, target in targets:
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + "." + uuid4().hex + ".partial")
            try:
                with archive.open(member) as source_file, temporary.open("wb") as output:
                    while block := source_file.read(1024**2):
                        output.write(block)
                os.replace(temporary, target)
            finally:
                temporary.unlink(missing_ok=True)


def _verify_installed(paths, purelib, frontend, release):
    for asset in release["assets"]:
        role = asset["role"]
        with zipfile.ZipFile(paths[role]) as archive:
            for member in _members(archive):
                name = member.filename
                if role == "frontend":
                    base = frontend
                elif name.endswith(".py") and name.split("/")[0] in {asset["namespace"], "GrainBot"}:
                    base = purelib
                else:
                    continue
                installed = base / name
                if not installed.resolve().is_relative_to(base) or not installed.is_file():
                    raise ValueError("Published application file is missing or outside its installation")
                expected = hashlib.sha256(archive.read(member)).hexdigest()
                if sha256(installed) != expected:
                    raise ValueError("Installed published application file changed")


def verify(installation):
    root = Path(installation).resolve()
    record_path = root / "config" / "published-application.json"
    if not record_path.resolve().is_relative_to(root):
        raise ValueError("Application record escapes installation")
    record = json.loads(record_path.read_text(encoding="utf-8"))
    release = catalog()
    if record.get("repository") != release["repository"] or record.get("tag") != release["tag"] or record.get("assets") != release["assets"]:
        state_path = root / "config" / "application-updates.json"
        if not state_path.resolve().is_relative_to(root):
            raise ValueError("Application update state escapes installation")
        if not state_path.is_file():
            raise ValueError("Installed application record differs from the pinned published release")
        state = json.loads(state_path.read_text(encoding="utf-8"))
        release = validate_release(state.get("installed", {}))
    expected = {"schema_version": 1, "repository": release["repository"], "tag": release["tag"],
                "release_url": release["release_url"], "assets": release["assets"]}
    if any(record.get(key) != value for key, value in expected.items()):
        raise ValueError("Installed application record differs from the pinned published release")
    profile, python, purelib = _runtime(root, record["runtime_python"], release)
    frontend = _release_directory(root, "applications", release) / "frontend"
    if frontend.resolve() != frontend:
        raise ValueError("Published frontend directory redirects outside installation")
    if not purelib.is_relative_to(root) or not frontend.is_relative_to(root) or record.get("profile") != profile:
        raise ValueError("Published application directory escapes installation")
    if Path(record["backend"]).resolve() != purelib or Path(record["frontend"]).resolve() != frontend:
        raise ValueError("Installed application record redirects package directories")
    paths = _cache(root, release)
    _verify_installed(paths, purelib, frontend, release)
    return {**record, "backend": str(purelib), "frontend": str(frontend), "runtime_python": str(python)}


def _check_dependencies(python, paths, environment):
    """Check wheel requirements against existing libraries without fetching any."""
    script = """import email,json,sys,zipfile
from importlib.metadata import distributions
try:
 from packaging.requirements import Requirement
except ImportError:
 from pip._vendor.packaging.requirements import Requirement
def norm(name): return name.lower().replace('_','-').replace('.','-')
versions={norm(d.metadata['Name']):d.version for d in distributions() if d.metadata['Name']}
metadata=[]
for path in sys.argv[1:]:
 with zipfile.ZipFile(path) as archive:
  names=[n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
  if len(names)!=1: raise ValueError('Published wheel must contain one package metadata record')
  data=email.message_from_bytes(archive.read(names[0]))
  versions[norm(data['Name'])]=data['Version']; metadata.append(data)
errors=[]
for data in metadata:
 for line in data.get_all('Requires-Dist',[]):
  r=Requirement(line)
  if r.marker and not r.marker.evaluate({'extra':''}): continue
  version=versions.get(norm(r.name))
  if not version or (r.specifier and version not in r.specifier):
   errors.append(data['Name']+' requires '+line+'; installed '+str(version))
if errors: raise SystemExit('Application dependencies are not satisfied: '+ '; '.join(errors))
"""
    result = subprocess.run([str(python), "-c", script,
                             *[str(paths[role]) for role in ("maintenance", "matmorph", "backend")]],
                            env=environment, capture_output=True, text=True, encoding="utf-8")
    if result.returncode:
        raise ValueError((result.stderr or result.stdout or "Application dependency verification failed").strip())


class _ApplicationProcessError(subprocess.CalledProcessError):
    def __str__(self):
        details = "\n".join(value.strip() for value in (self.stdout, self.stderr) if value and value.strip())
        return super().__str__() + ("\n" + details if details else "")


def _run_pip(command, environment):
    """Keep pip logs out of the bridge JSON stream and preserve failure details."""
    try:
        return subprocess.run(command, env=environment, check=True,
                              capture_output=True, text=True, encoding="utf-8")
    except subprocess.CalledProcessError as error:
        raise _ApplicationProcessError(error.returncode, error.cmd, output=error.stdout,
                                       stderr=error.stderr) from error


def install(installation, runtime_python, release=None):
    root = Path(installation).resolve()
    if not (root / "config" / "published-application.json").resolve().is_relative_to(root):
        raise ValueError("Application record escapes installation")
    updating = release is not None
    release = catalog() if release is None else validate_release(release)
    profile, python, purelib = _runtime(root, runtime_python, release)
    print("Downloading and verifying the published application…", flush=True)
    paths = _cache(root, release, download=True)
    frontend = _release_directory(root, "applications", release) / "frontend"
    # Verify ZIP structure before mutating the application environment.
    for path in paths.values():
        with zipfile.ZipFile(path) as archive:
            _members(archive)
    environment = os.environ.copy()
    environment["PYTHONUTF8"] = "1"
    # Application package installation must not inherit the control import path.
    environment.pop("PYTHONPATH", None)
    environment.pop("PYTHONHOME", None)
    if updating or profile == "portable":
        _check_dependencies(python, paths, environment)
    print("Installing published Python packages into the application environment…", flush=True)
    options = ["--target", str(purelib), "--upgrade"] if profile == "portable" else ["--force-reinstall"]
    _run_pip([str(python), "-m", "pip", "install", "--no-deps", *options,
                    *[str(paths[role]) for role in ("maintenance", "matmorph", "backend")]],
                   environment)
    if profile == "portable":
        check = "import sys,runpy; sys.path.insert(0,sys.argv.pop(1)); sys.argv=['pip','check']; runpy.run_module('pip',run_name='__main__')"
        _run_pip([str(python), "-c", check, str(purelib)], environment)
    else:
        _run_pip([str(python), "-m", "pip", "check"], environment)
        result = subprocess.run([str(python), "-c", "import json,sysconfig; print(json.dumps(sysconfig.get_paths()['purelib']))"],
                            env=environment, check=True, capture_output=True, text=True, encoding="utf-8")
        if Path(json.loads(result.stdout)).resolve() != purelib or not purelib.is_relative_to(root):
            raise ValueError("Application environment has an unexpected package directory")
    print("Installing and verifying frontend files…", flush=True)
    _extract_frontend(paths["frontend"], frontend, root)
    _verify_installed(paths, purelib, frontend.resolve(), release)
    record = {"schema_version": 1, "repository": release["repository"], "tag": release["tag"],
              "release_url": release["release_url"], "assets": release["assets"], "profile": profile,
              "runtime_python": str(python), "backend": str(purelib), "frontend": str(frontend.resolve())}
    atomic_json(root / "config" / "published-application.json", record)
    print("Published application installed and verified.", flush=True)
    return record


def main():
    parser = argparse.ArgumentParser(description="Install the pinned official GrainBot application release")
    parser.add_argument("--installation", type=Path, required=True)
    parser.add_argument("--runtime-python", type=Path)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    if args.verify:
        result = verify(args.installation)
    elif args.runtime_python:
        result = install(args.installation, args.runtime_python)
    else:
        parser.error("--runtime-python is required for installation")
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
