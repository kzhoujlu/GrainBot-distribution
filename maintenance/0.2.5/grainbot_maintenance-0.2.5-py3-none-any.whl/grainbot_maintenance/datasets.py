"""Data-only versions using the MatMorph dataset manifest; never execute dataset code."""
import json
from pathlib import Path
from .integrity import sha256

DATA_SUFFIXES = {".json", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp", ".csv", ".txt", ".md", ".npy", ".npz", ".h5", ".hdf5"}


def validate_manifest(data, folder, inventory):
    if data.get("schema_version") != "1.0" or not all(data.get(key) for key in ("dataset_id", "name", "version", "samples", "license")):
        raise ValueError("Dataset requires a versioned MatMorph manifest and license")
    root = Path(folder).resolve()
    ids, splits, artifacts = set(), {}, []
    for sample in data["samples"]:
        if not sample.get("sample_id") or sample["sample_id"] in ids or not sample.get("group_id"):
            raise ValueError("Dataset sample IDs must be unique and group IDs declared")
        ids.add(sample["sample_id"])
        split = sample.get("split", "unassigned")
        if split not in {"unassigned", "train", "validation", "test"}:
            raise ValueError("Unknown dataset split")
        if split != "unassigned":
            group = splits.setdefault(sample["group_id"], split)
            if group != split:
                raise ValueError("Dataset group crosses train/validation/test splits")
        artifacts.append(sample["image"])
        for annotation in sample.get("annotations", []):
            artifacts.append(annotation["artifact"])
            if annotation.get("valid_mask"):
                artifacts.append(annotation["valid_mask"])
    for artifact in artifacts:
        relative = artifact["path"]
        path = (root / relative).resolve()
        declared = "payload/" + relative
        if "\\" in relative or ":" in relative or not path.is_relative_to(root) or declared not in inventory:
            raise ValueError("Dataset artifact must remain inside signed resource inventory")
        if not path.is_file() or not artifact.get("sha256") or sha256(path) != artifact["sha256"] or inventory[declared] != artifact["sha256"]:
            raise ValueError("Dataset artifact missing or hash mismatch")
    return {"dataset_id": data["dataset_id"], "version": data["version"], "samples": len(ids), "artifact_count": len(artifacts), "validation": "manifest, splits, paths and hashes", "human_review": "pending"}


def trial(record):
    folder = Path(record["path"])
    inventory = dict(record["manifest"]["files"])
    inventory.update({item["target"]: item["sha256"] for item in record["manifest"].get("resources", [])})
    data = json.loads((folder / "payload/dataset.json").read_text(encoding="utf-8"))
    report = validate_manifest(data, folder / "payload", inventory)
    if data["version"] != record["manifest"]["version"]:
        raise ValueError("Dataset version must match signed release version")
    return report
