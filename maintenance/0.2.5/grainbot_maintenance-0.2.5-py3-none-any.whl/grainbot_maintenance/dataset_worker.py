"""Trusted data validation worker; dataset downloads do not supply executable tests."""
import json
from pathlib import Path
import sys


def main():
    from matmorph.data.manifest import DatasetManifest
    import cv2
    import numpy as np
    from matmorph.postprocess.instance_postprocessing import label_boundaries
    folder = Path(sys.argv[1]) / "payload"
    manifest = DatasetManifest.model_validate_json((folder / "dataset.json").read_text(encoding="utf-8"))
    manifest.validate_files(folder, verify_hashes=True)
    preview = Path(sys.argv[1]) / "trial-results"
    preview.mkdir(exist_ok=True)
    for index, sample in enumerate(manifest.samples):
        rendered = False
        image = cv2.imread(str(folder / sample.image.path), cv2.IMREAD_UNCHANGED)
        if image is None or image.shape[:2] != (sample.shape.height, sample.shape.width):
            raise ValueError("Dataset image dimensions or encoding do not match manifest")
        for annotation in sample.annotations:
            if annotation.kind.value in {"semantic_map", "instance_map", "boundary_mask"}:
                label = cv2.imread(str(folder / annotation.artifact.path), cv2.IMREAD_UNCHANGED)
                if label is None or label.ndim != 2 or label.shape != image.shape[:2]:
                    raise ValueError("Dataset label dimensions or encoding do not match image")
                if index < 3 and not rendered:
                    display = image if image.dtype == np.uint8 else cv2.normalize(image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
                    if display.ndim == 2:
                        display = cv2.cvtColor(display, cv2.COLOR_GRAY2BGR)
                    if display.shape[2] == 4:
                        display = cv2.cvtColor(display, cv2.COLOR_BGRA2BGR)
                    boundary = (label == 0 if annotation.boundary_polarity == "dark" else label > 0) if annotation.kind.value == "boundary_mask" else label_boundaries(label, include_outer=True, thickness=1)
                    overlay = display.copy()
                    overlay[boundary] = (255, 190, 30)
                    cv2.imwrite(str(preview / f"{index}-0-input.png"), display)
                    cv2.imwrite(str(preview / f"{index}-1-labels.png"), overlay)
                    rendered = True
    print(json.dumps({"dataset": manifest.dataset_id, "samples": len(manifest.samples), "validation": "MatMorph schema, hashes and image/label dimensions", "human_review": "pending"}))


if __name__ == "__main__":
    main()
