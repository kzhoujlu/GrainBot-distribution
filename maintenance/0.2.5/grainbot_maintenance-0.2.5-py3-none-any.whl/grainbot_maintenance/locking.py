"""Serialize state writes from the local launcher and web service."""
import os
from pathlib import Path
import threading
import time


class WorkspaceLock:
    def __init__(self, path):
        self.path = Path(path)
        self.thread = threading.RLock()
        self.local = threading.local()

    def __enter__(self):
        self.thread.acquire()
        depth = getattr(self.local, "depth", 0)
        if depth:
            self.local.depth += 1
            return self
        file = self.path.open("a+b")
        try:
            if file.tell() == 0:
                file.write(b"0")
                file.flush()
            deadline = time.monotonic() + 30
            while True:
                try:
                    file.seek(0)
                    if os.name == "nt":
                        import msvcrt
                        msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError("Another maintenance operation is using this workspace")
                    time.sleep(.1)
        except Exception:
            file.close()
            self.thread.release()
            raise
        self.local.file, self.local.depth = file, 1
        return self

    def __exit__(self, *error):
        self.local.depth -= 1
        if not self.local.depth:
            file = self.local.file
            file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(file.fileno(), fcntl.LOCK_UN)
            file.close()
        self.thread.release()
