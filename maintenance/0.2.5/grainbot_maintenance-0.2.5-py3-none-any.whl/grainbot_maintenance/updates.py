"""Trusted GitHub component lifecycle with checksums and optional release signatures."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from uuid import uuid4
from .integrity import sha256 as file_hash

API_VERSION = 1
KINDS = {"frontend", "backend", "model", "dataset"}
SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$")
REPO = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


def identifier(value):
    if not isinstance(value, str) or not SAFE.fullmatch(value) or value in {".", ".."}:
        raise ValueError("Invalid component or version identifier")
    return value


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid4().hex + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def github_download(url, destination, limit):
    from urllib.parse import urlsplit
    def check(target):
        parsed = urlsplit(target)
        if parsed.scheme != "https" or parsed.username or parsed.hostname not in {
            "api.github.com", "github.com", "raw.githubusercontent.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"}:
            raise ValueError("Release download must remain on GitHub HTTPS hosts")
    class Redirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, message, headers, newurl):
            check(newurl)
            return super().redirect_request(request, fp, code, message, headers, newurl)
    check(url)
    request = urllib.request.Request(url, headers={"User-Agent": "GrainBot-Component-Updater", "Accept": "application/vnd.github+json"})
    with urllib.request.build_opener(Redirect()).open(request, timeout=60) as response, destination.open("wb") as output:
        count = 0
        while chunk := response.read(1024 * 1024):
            count += len(chunk)
            if count > limit:
                raise ValueError("Release asset exceeds configured size limit")
            output.write(chunk)


class ComponentUpdates:
    def __init__(self, workspace: Path):
        self.root = Path(workspace).resolve() / "updates"
        self.root.mkdir(parents=True, exist_ok=True)
        from .locking import WorkspaceLock
        self.lock = WorkspaceLock(self.root / "state.lock")

    def _read(self, name, default):
        path = self.root / name
        return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default

    def status(self):
        return {"sources": self._read("sources.json", {}), "active": self._read("active.json", {}),
            "staged": self._read("staged.json", {}), "history": self._read("history.json", []),
            "candidates": self._read("candidates.json", {}), "api_version": API_VERSION, "automatic_activation": False}

    def source(self, component, repository, public_key="", kind=None):
        identifier(component)
        from .github_source import parse_github_source
        parsed = parse_github_source(repository)
        if public_key:
            try:
                valid_key = len(base64.b64decode(public_key, validate=True)) == 32
            except (ValueError, TypeError):
                valid_key = False
            if not valid_key:
                raise ValueError("Optional signing key must be a base64 Ed25519 public key")
        if kind and kind not in KINDS:
            raise ValueError("Unsupported component kind")
        with self.lock:
            sources = self._read("sources.json", {})
            sources[component] = {"repository": parsed["repository"], "public_key": public_key or ""}
            if parsed["tag"]:
                sources[component]["tag"] = parsed["tag"]
            if kind:
                sources[component]["kind"] = kind
            atomic_json(self.root / "sources.json", sources)
        return self.status()

    def check(self, component):
        identifier(component)
        source = self._read("sources.json", {}).get(component)
        if not source or not source.get("repository"):
            raise ValueError("Configure a trusted GitHub repository or release link first")
        temporary = self.root / ("check-" + uuid4().hex + ".json")
        try:
            from .github_source import release_api_url
            github_download(release_api_url(source), temporary, 4*1024**2)
            release = json.loads(temporary.read_text(encoding="utf-8"))
        finally:
            temporary.unlink(missing_ok=True)
        if release.get("draft") or release.get("prerelease"):
            raise ValueError("Only published stable releases are eligible")
        required = [component + ".manifest.json"]
        if source.get("public_key"):
            required.append(component + ".manifest.sig")
        from .release_metadata import release_files
        metadata = release_files(release, source["repository"], self.root)
        assets = metadata["assets"]
        if any(name not in assets for name in required):
            raise ValueError("Unsupported release format: missing component manifest" +
                (" or required signature asset" if source.get("public_key") else " asset"))
        candidate = {"tag": release["tag_name"], "release_url": release["html_url"],
            "assets": assets, "source": source, "notes": release.get("body", "")}
        if metadata["hashes"]:
            candidate["metadata_hashes"] = metadata["hashes"]
            candidate["metadata_revision"] = metadata["revision"]
        with self.lock:
            candidates = self._read("candidates.json", {})
            candidates[component] = candidate
            atomic_json(self.root / "candidates.json", candidates)
        return {"component": component, "tag": candidate["tag"], "release_url": candidate["release_url"], "notes": candidate["notes"]}

    def download(self, component):
        identifier(component)
        candidate = self._read("candidates.json", {}).get(component)
        if not candidate or candidate["source"] != self._read("sources.json", {}).get(component):
            raise ValueError("Check the configured repository again before downloading")
        temporary = self.root / ("download-" + uuid4().hex)
        temporary.mkdir()
        try:
            manifest = temporary / "manifest.json"
            signature = temporary / "manifest.sig" if candidate["source"].get("public_key") else None
            github_download(candidate["assets"][component + ".manifest.json"], manifest, 32*1024**2)
            if candidate.get("metadata_hashes") and file_hash(manifest) != candidate["metadata_hashes"][component + ".manifest.json"]:
                raise ValueError("Component metadata SHA256 mismatch")
            if signature:
                github_download(candidate["assets"][component + ".manifest.sig"], signature, 1024)
                if candidate.get("metadata_hashes") and file_hash(signature) != candidate["metadata_hashes"][component + ".manifest.sig"]:
                    raise ValueError("Component signature SHA256 mismatch")
            data = self.verify_manifest(component, manifest, signature)
            if (self.root / "packages" / component / data["version"]).exists():
                raise ValueError("This component version is already downloaded")
            asset = data["archive"]
            archive = temporary / "package.zip"
            if data.get("archive_parts"):
                cache = self.root / "download-cache" / data["sha256"]
                cache.mkdir(parents=True, exist_ok=True)
                with archive.open("wb") as assembled:
                    for index, part in enumerate(data["archive_parts"]):
                        if part["name"] not in candidate["assets"]:
                            raise ValueError("Declared archive part is missing from release")
                        cached = cache / str(index)
                        if not cached.is_file() or file_hash(cached) != part["sha256"]:
                            github_download(candidate["assets"][part["name"]], cached, 1024**3)
                        if file_hash(cached) != part["sha256"]:
                            raise ValueError("Archive part SHA256 mismatch")
                        with cached.open("rb") as handle:
                            shutil.copyfileobj(handle, assembled, length=1024**2)
            else:
                if asset not in candidate["assets"]:
                    raise ValueError("Declared archive is missing from GitHub release")
                github_download(candidate["assets"][asset], archive, 16 * 1024**3)
            return self.stage(component, manifest, signature, archive)
        finally:
            shutil.rmtree(temporary)

    def verify_manifest(self, component, manifest, signature=None):
        source = self._read("sources.json", {}).get(component)
        if not source:
            raise ValueError("No trusted component source configured")
        if source.get("public_key"):
            if signature is None or not Path(signature).is_file():
                raise ValueError("Configured signing key requires a release signature")
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            Ed25519PublicKey.from_public_bytes(base64.b64decode(source["public_key"])).verify(
                base64.b64decode(Path(signature).read_bytes(), validate=True), manifest.read_bytes())
        data = json.loads(manifest.read_text(encoding="utf-8"))
        if data.get("component") != component or data.get("kind") not in KINDS or data.get("api_version") != API_VERSION:
            raise ValueError("Incompatible component manifest")
        if source.get("kind") and source["kind"] != data["kind"]:
            raise ValueError("Release kind differs from configured component kind")
        digest_pattern = re.compile(r"^[a-f0-9]{64}$")
        if not isinstance(data.get("sha256"), str) or not digest_pattern.fullmatch(data["sha256"]):
            raise ValueError("Invalid archive digest")
        if not isinstance(data.get("archive"), str) or Path(data["archive"]).name != data["archive"] or "\\" in data["archive"]:
            raise ValueError("Archive must be a filename")
        identifier(data["version"])
        from .resources import validate
        for resource in data.get("resources", []):
            validate(resource)
        if not isinstance(data.get("files"), dict) or not data["files"] or (data["kind"] != "dataset" and "selftest.py" not in data["files"]):
            raise ValueError("Package must declare all files and a selftest.py")
        if data["kind"] == "dataset":
            from .datasets import DATA_SUFFIXES
            if any(Path(name).suffix.lower() not in DATA_SUFFIXES for name in [*data["files"], *[r["target"] for r in data.get("resources", [])]]):
                raise ValueError("Dataset packages may contain data only, no executable code")
        if any(not isinstance(digest, str) or not digest_pattern.fullmatch(digest) for digest in data["files"].values()):
            raise ValueError("Invalid file digest")
        if "archive_parts" in data:
            parts = data["archive_parts"]
            if not isinstance(parts, list) or not 1 <= len(parts) <= 1000:
                raise ValueError("Invalid archive part inventory")
            names = set()
            for part in parts:
                name = part.get("name", "")
                if not name or Path(name).name != name or "\\" in name or name in names or not digest_pattern.fullmatch(part.get("sha256", "")):
                    raise ValueError("Invalid archive part")
                names.add(name)
        return data

    def stage(self, component, manifest, signature=None, archive=None):
        identifier(component)
        data = self.verify_manifest(component, manifest, signature)
        if file_hash(archive) != data["sha256"]:
            raise ValueError("Archive SHA256 mismatch")
        version = data["version"]
        destination = self.root / "packages" / component / version
        with self.lock:
            if destination.exists():
                raise ValueError("This immutable component version is already downloaded")
            temporary = self.root / ("extract-" + uuid4().hex)
            temporary.mkdir()
            try:
                with zipfile.ZipFile(archive) as package:
                    names = set()
                    total = 0
                    for member in package.infolist():
                        target = (temporary / member.filename).resolve()
                        if not target.is_relative_to(temporary) or "\\" in member.filename or member.filename in names or (member.external_attr >> 16) & 0o170000 == 0o120000:
                            raise ValueError("Unsafe or duplicate package path")
                        if member.is_dir():
                            continue
                        total += member.file_size
                        if total > 32 * 1024**3 or member.filename not in data["files"]:
                            raise ValueError("Undeclared file or excessive archive size")
                        names.add(member.filename)
                    if names != set(data["files"]):
                        raise ValueError("Package file inventory mismatch")
                    package.extractall(temporary)
                for name, digest in data["files"].items():
                    if file_hash(temporary / name) != digest:
                        raise ValueError("Package file SHA256 mismatch")
                self._contract(data, temporary)
                destination.parent.mkdir(parents=True, exist_ok=True)
                temporary.rename(destination)
                record = {"manifest": data, "status": "downloaded", "source": self._read("sources.json", {})[component],
                    "path": str(destination), "review": "pending"}
                staged = self._read("staged.json", {})
                staged[component + ":" + version] = record
                atomic_json(self.root / "staged.json", staged)
            finally:
                if temporary.exists():
                    shutil.rmtree(temporary)
        return record

    @staticmethod
    def _contract(manifest, folder):
        kind = manifest["kind"]
        required = {"frontend": "payload/index.html", "backend": "payload/grainbot_studio/app.py",
            "model": "payload/adapter.py", "dataset": "payload/dataset.json"}[kind]
        if not (folder / required).is_file():
            raise ValueError(f"Missing {kind} entrypoint: {required}")

    def test(self, component, version):
        key = identifier(component) + ":" + identifier(version)
        with self.lock:
            staged = self._read("staged.json", {})
            record = staged.get(key)
            if not record:
                raise ValueError("Download this component version first")
            folder = Path(record["path"])
            self._verify_record(record)
            if record["manifest"]["kind"] == "dataset":
                from .datasets import trial
                try:
                    report = trial(record)
                    runtime = os.environ.get("GRAINBOT_RUNTIME_PYTHON", sys.executable)
                    env = os.environ.copy()
                    # Worker code belongs to the installed maintenance package, not the downloaded dataset.
                    libraries = [str(Path(__file__).resolve().parents[1])]
                    backend = next((r for r in self._read("active.json", {}).values() if r["kind"] == "backend"), None)
                    if backend:
                        libraries.append(str(Path(backend["path"]) / "payload/matmorph-src"))
                    env["PYTHONPATH"] = os.pathsep.join(filter(None, [*libraries, env.get("PYTHONPATH")]))
                    result = subprocess.run([runtime, "-m", "grainbot_maintenance.dataset_worker", str(folder)], capture_output=True, text=True, encoding="utf-8", timeout=180, env=env)
                    record["status"] = "tested" if result.returncode == 0 else "failed"
                    record["trial"] = {"exit_code": result.returncode, "stdout": json.dumps(report)+"\n"+result.stdout[-8000:], "stderr": result.stderr[-8000:], "artifacts": sorted(p.name for p in (folder / "trial-results").glob("*.png"))}
                except (ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as error:
                    record["status"] = "failed"
                    record["trial"] = {"exit_code": 1, "stdout": "", "stderr": str(error), "artifacts": []}
                staged[key] = record
                atomic_json(self.root / "staged.json", staged)
                return record
            env = os.environ.copy()
            env["GRAINBOT_COMPONENT_ROOT"] = str(folder)
            env["GRAINBOT_WORKSPACE"] = str(folder / "trial-workspace")
            if record.get("trial_image"):
                env["GRAINBOT_TRIAL_IMAGE"]=record["trial_image"]
            runtime = next((r for r in self._read("active.json", {}).values() if r["kind"] == "runtime"), None)
            executable = sys.executable
            if record["manifest"]["kind"] in {"backend", "model"}:
                executable = str(Path(runtime["path"]) / "payload/python.exe") if runtime else os.environ.get("GRAINBOT_RUNTIME_PYTHON", sys.executable)
            result = subprocess.run([executable, str(folder / "selftest.py")], cwd=folder, env=env,
                capture_output=True, text=True, timeout=180)
            record["status"] = "tested" if result.returncode == 0 else "failed"
            record["trial"] = {"exit_code": result.returncode, "stdout": result.stdout[-8000:], "stderr": result.stderr[-8000:]}
            record["trial"]["artifacts"] = [p.name for p in (folder / "trial-results").glob("*")
                if p.is_file() and p.suffix in {".png", ".json"}]
            staged[key] = record
            atomic_json(self.root / "staged.json", staged)
        return record

    @staticmethod
    def _verify_record(record):
        folder = Path(record["path"])
        for name, digest in record["manifest"]["files"].items():
            if file_hash(folder / name) != digest:
                raise ValueError("Installed component files changed; activation refused")
        from .resources import verify
        verify(record["manifest"], folder)

    def prepare_resources(self, component, version):
        key=identifier(component)+":"+identifier(version)
        with self.lock:
            record=self._read("staged.json",{}).get(key)
            if not record:
                raise ValueError("Download code first")
            from .resources import prepare
            return prepare(record["manifest"], record["path"], self.root/"resource-cache")

    def save_trial_image(self, component, version, image):
        key=identifier(component)+":"+identifier(version)
        if len(image)>20*1024**2 or not (image.startswith(b"\x89PNG\r\n\x1a\n") or image.startswith(b"\xff\xd8")):
            raise ValueError("Trial input must be a PNG/JPEG under 20 MB")
        with self.lock:
            staged=self._read("staged.json",{})
            record=staged.get(key)
            if not record:
                raise ValueError("Download the code component first")
            folder=Path(record["path"])/"trial-input"
            folder.mkdir(exist_ok=True)
            file=folder/"source.png"
            file.write_bytes(image)
            record["trial_image"]=str(file)
            record["status"]="downloaded"
            record["review"]="pending"
            staged[key]=record
            atomic_json(self.root/"staged.json",staged)
        return {"status":"trial_input_saved","sha256":file_hash(file)}

    def activate(self, component, version, decision):
        if decision != "accept":
            raise ValueError("Explicit human acceptance is required")
        return self._select(component, version, scientific_review=True)

    def enable(self, component, version):
        """Enable a verified release from the configured trusted upstream."""
        return self._select(component, version, scientific_review=False)

    def _select(self, component, version, *, scientific_review):
        key = identifier(component) + ":" + identifier(version)
        with self.lock:
            staged = self._read("staged.json", {})
            record = staged.get(key)
            allowed = {"tested"} if scientific_review else {"downloaded", "tested"}
            if not record or record["status"] not in allowed:
                raise ValueError("Independent trial must pass before activation")
            self._verify_record(record)
            active = self._read("active.json", {})
            kind = record["manifest"]["kind"]
            if kind in {"frontend", "backend"} and any(c != component and v["kind"] == kind for c, v in active.items()):
                raise ValueError("Only one frontend, backend or runtime component can be active")
            previous = active.get(component)
            active[component] = {"version": version, "kind": kind, "path": record["path"], "manifest": record["manifest"]}
            if scientific_review:
                record["review"] = "accept"
            record["activation_policy"] = "scientific_review" if scientific_review else "trusted_upstream"
            staged[key] = record
            history = self._read("history.json", [])
            history.append({"component": component, "previous": previous, "selected": version, "action": "activate"})
            atomic_json(self.root / "staged.json", staged)
            atomic_json(self.root / "history.json", history)
            atomic_json(self.root / "active.json", active)
        return {"status": "accepted" if scientific_review else "enabled", "restart_required": True, "version": version}

    def disable(self, component):
        identifier(component)
        with self.lock:
            active = self._read("active.json", {})
            if component not in active:
                raise ValueError("Component is not enabled")
            previous = active.pop(component)
            history = self._read("history.json", [])
            history.append({"component": component, "action": "disable", "previous": previous})
            atomic_json(self.root / "history.json", history)
            atomic_json(self.root / "active.json", active)
        return {"status": "disabled", "restart_required": True, "files_retained": True}

    def review(self, component, version, decision):
        if decision not in {"reject", "needs_changes"}:
            raise ValueError("Review decision must be reject or needs_changes")
        key = identifier(component) + ":" + identifier(version)
        with self.lock:
            staged = self._read("staged.json", {})
            if key not in staged:
                raise ValueError("Download this version first")
            staged[key]["review"] = decision
            atomic_json(self.root / "staged.json", staged)
        return {"review": decision, "active_versions_unchanged": True}

    def rollback(self, component):
        identifier(component)
        with self.lock:
            active = self._read("active.json", {})
            history = self._read("history.json", [])
            last = next((event for event in reversed(history) if event["component"] == component), None)
            if not last or last["action"] not in {"activate", "disable"}:
                raise ValueError("No previous activation to roll back")
            previous = last["previous"]
            if previous:
                self._verify_record({"path": previous["path"], "manifest": previous["manifest"]})
                active[component] = previous
            else:
                active.pop(component)
            history.append({"component": component, "action": "rollback", "selected": previous})
            atomic_json(self.root / "history.json", history)
            atomic_json(self.root / "active.json", active)
        return {"status": "rolled_back", "restart_required": True}
