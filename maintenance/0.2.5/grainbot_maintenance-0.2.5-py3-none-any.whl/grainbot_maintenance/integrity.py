"""Common content identity operations, independent of scientific libraries."""
import hashlib

def sha256(path):
    digest=hashlib.sha256()
    with path.open("rb") as handle:
        while block:=handle.read(1024**2):digest.update(block)
    return digest.hexdigest()
