"""Select verified application code before importing any scientific modules."""
import os
from pathlib import Path
import sys
import importlib.util


def main():
    backend = Path(os.environ["GRAINBOT_BACKEND_SRC"])
    paths = [str(backend), str(backend / "matmorph-src")]
    if os.environ.get("GRAINBOT_MATMORPH_SRC"):
        paths.append(os.environ["GRAINBOT_MATMORPH_SRC"])
    if os.environ.get("GRAINBOT_UPDATER_DEPENDENCIES"):
        paths.append(os.environ["GRAINBOT_UPDATER_DEPENDENCIES"])
    sys.path[:0] = paths
    from grainbot_studio import paths as application_paths
    application_paths.FRONTEND_DIST = Path(os.environ["GRAINBOT_FRONTEND_DIST"])
    if sys.argv[1] == "web":
        from grainbot_studio.server import main as start
        start(sys.argv[2:])
    else:
        spec = importlib.util.spec_from_file_location("grainbot_native_startup", Path(__file__).with_name("startup.py"))
        startup = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(startup)
        startup.report("loading", "Loading application modules")
        try:
            from grainbot_studio import desktop
            if not getattr(desktop, "DESKTOP_READINESS_PROTOCOL", 0):
                # Adapt older published desktop entrypoints without modifying their package files.
                import webview
                original_create = webview.create_window
                def create_window(title, url, *args, **kwargs):
                    startup.report("window", "Creating desktop window")
                    window = original_create(title, url, *args, **kwargs)
                    window.events.loaded += lambda: startup.page_ready(window, url)
                    window.events.closed += lambda: startup.report("closed")
                    startup.report("page", "Loading Studio page")
                    return window
                webview.create_window = create_window
                startup.report("server", "Starting local API")
            desktop.main()
        except Exception as error:
            startup.report("failed", str(error))
            raise


if __name__ == "__main__":
    main()
