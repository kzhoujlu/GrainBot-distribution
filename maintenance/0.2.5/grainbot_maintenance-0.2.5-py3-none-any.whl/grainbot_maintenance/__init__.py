"""GrainBot installation and component lifecycle API."""
from .updates import ComponentUpdates

__version__ = "0.2.5"
__all__ = ["ComponentUpdates"]
