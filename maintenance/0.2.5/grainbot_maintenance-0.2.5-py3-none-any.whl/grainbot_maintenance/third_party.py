"""Install reviewed adapters while fetching third-party files from pinned official sources."""
from __future__ import annotations

import base64
import hashlib
from importlib.resources import files
import json
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from .integrity import sha256


def _catalog():
    data = json.loads(files(__package__).joinpath("builtin_models.json").read_text(encoding="utf-8"))
    if data.get("schema_version") != 1:
        raise ValueError("Unsupported built-in model catalog")
    return data["models"]


def _entry(component):
    entry = next((item for item in _catalog() if item["component"] == component), None)
    if entry is None:
        raise ValueError("Unknown built-in model")
    manifest = base64.b64decode(entry["manifest_base64"], validate=True)
    archive = base64.b64decode(entry["archive_base64"], validate=True)
    if (hashlib.sha256(manifest).hexdigest() != entry["manifest_sha256"]
            or hashlib.sha256(archive).hexdigest() != entry["archive_sha256"]):
        raise ValueError("Built-in model catalog integrity check failed")
    signed = json.loads(manifest)
    if (signed["component"] != component or signed["kind"] != "model"
            or signed["version"] != entry["version"] or signed["sha256"] != entry["archive_sha256"]
            or signed.get("upstream_code_bundled") is not False or signed.get("weights_bundled") is not False):
        raise ValueError("Invalid built-in model adapter contract")
    for resource in signed.get("resources", []):
        source = resource["source"]
        if (source["provider"] != "github" or source["repository"] != entry["repository"]
                or source["revision"] != entry["revision"]):
            raise ValueError("Built-in model must use its pinned official source")
    return entry, signed, manifest, archive


def catalog_rows(manager):
    """Advertise installable models without creating sources or downloading anything."""
    state = manager.status()
    rows = []
    for item in _catalog():
        component = item["component"]
        source = state["sources"].get(component)
        if source and source.get("public_key") != item["publisher_public_key"]:
            # A user's explicitly configured publisher takes precedence over the default catalog.
            continue
        active = state["active"].get(component)
        staged = state["staged"].get(component + ":" + item["version"])
        latest = next((event for event in reversed(state["history"]) if event["component"] == component), {})
        current = "enabled" if active else "disabled" if staged and latest.get("action") == "disable" else "downloaded" if staged else "available"
        rows.append({"id": component, "component": component, "kind": "model", "mode": "builtin_model",
            "name": item["name"], "description": item["description"], "managed": True,
            "repository": item["repository"], "upstream_url": item["upstream_url"],
            "upstream_revision": item["revision"], "version": active["version"] if active else staged["manifest"]["version"] if staged else "",
            "candidate": item["version"], "available_version": item["version"], "state": current,
            "active": bool(active), "rollback_available": latest.get("action") in {"activate", "disable"},
            "path": active["path"] if active else staged["path"] if staged else ""})
    return rows


def check(manager, component):
    """Compare the locally reviewed upstream release; never guess a nonexistent release URL."""
    entry, _, _, _ = _entry(component)
    active = manager.status()["active"].get(component)
    return {"component": component, "tag": entry["version"], "version": entry["version"],
        "current_version": active["version"] if active else "", "update_available": not active or active["version"] != entry["version"],
        "release_url": entry["upstream_url"], "upstream_revision": entry["revision"],
        "notes": "Reviewed official upstream revision. Code and weights download separately from the official repository."}


def download(manager, component):
    """Stage the original signed adapter and fetch verified upstream resources."""
    entry, manifest, manifest_bytes, archive_bytes = _entry(component)
    with manager.lock:
        source = manager.status()["sources"].get(component)
        if source and (source.get("public_key") != entry["publisher_public_key"] or source.get("kind", "model") != "model"):
            raise ValueError("This component has a custom publisher; use its configured update source")
        if not source:
            manager.source(component, "", entry["publisher_public_key"], "model")
        record = manager.status()["staged"].get(component + ":" + entry["version"])
        if record:
            if record["manifest"] != manifest or record["source"].get("public_key") != entry["publisher_public_key"]:
                raise ValueError("Installed adapter differs from the built-in signed version")
            for name, digest in manifest["files"].items():
                if sha256(Path(record["path"]) / name) != digest:
                    raise ValueError("Installed adapter files changed")
        else:
            with TemporaryDirectory(prefix="builtin-model-", dir=manager.root) as temporary:
                folder = Path(temporary)
                manifest_path, signature_path, archive_path = folder / "manifest.json", folder / "manifest.sig", folder / "adapter.zip"
                manifest_path.write_bytes(manifest_bytes)
                signature_path.write_bytes(base64.b64decode(entry["signature_base64"], validate=True))
                archive_path.write_bytes(archive_bytes)
                record = manager.stage(component, manifest_path, signature_path, archive_path)
        manager.prepare_resources(component, entry["version"])
        manager._verify_record(record)
        return record


LIBRARIES = (
    ("torch", "PyTorch", ("torch",)), ("torchvision", "Torchvision", ("torchvision",)),
    ("numpy", "NumPy", ("numpy",)), ("cv2", "OpenCV", ("opencv-python-headless", "opencv-python")),
    ("scipy", "SciPy", ("scipy",)), ("skimage", "scikit-image", ("scikit-image",)),
    ("sklearn", "scikit-learn", ("scikit-learn",)), ("PIL", "Pillow", ("Pillow",)),
    ("fastapi", "FastAPI", ("fastapi",)), ("pip", "pip", ("pip",)),
)
_REQUIRED = {"torch", "numpy", "cv2", "sklearn", "PIL", "scipy"}


def _probe(runtime_python, *, imports=False):
    """Only launch the selected local Python; metadata probes do not import scientific libraries."""
    python = Path(runtime_python).resolve()
    if not python.is_file():
        raise ValueError("Selected Python runtime is unavailable; install or repair the runtime first")
    script = '''import importlib, importlib.metadata, importlib.util, json, sys
items=json.loads(sys.argv[1]); do_import=sys.argv[2]=='imports'; rows=[]
for module, name, distributions in items:
    version=''; error=''; present=importlib.util.find_spec(module) is not None
    for distribution in distributions:
        try: version=importlib.metadata.version(distribution); break
        except importlib.metadata.PackageNotFoundError: pass
    if do_import and present:
        try: importlib.import_module(module)
        except Exception as failure: error=str(failure); present=False
    rows.append({'module':module, 'name':name, 'version':version, 'available':present, 'error':error})
print(json.dumps({'libraries':rows}))'''
    selected = [item for item in LIBRARIES if not imports or item[0] in _REQUIRED]
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env.pop("PYTHONSTARTUP", None)
    try:
        result = subprocess.run([str(python), "-c", script, json.dumps(selected), "imports" if imports else "metadata"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120 if imports else 30, env=env)
    except subprocess.TimeoutExpired as error:
        raise ValueError("Python runtime check timed out; repair the selected environment") from error
    if result.returncode:
        raise ValueError("Python runtime check failed: " + result.stderr[-2000:])
    try:
        report = json.loads(result.stdout)
    except (ValueError, TypeError) as error:
        raise ValueError("Python runtime returned an invalid dependency report") from error
    if not isinstance(report.get("libraries"), list):
        raise ValueError("Python runtime returned an invalid dependency report")
    return report


def libraries(runtime_python):
    report = _probe(runtime_python)
    return {**report, "runtime_python": str(Path(runtime_python).resolve()),
        "installation_method": "Use the installer's CPU/CUDA environment installation or repair.", "automatic_upgrade": False}


def install(manager, component, runtime_python):
    """Check runtime compatibility and enable; scientific evaluation remains a separate workflow."""
    entry, _, _, _ = _entry(component)
    dependencies = _probe(runtime_python, imports=True)
    by_module = {item["module"]: item for item in dependencies["libraries"]}
    missing = sorted(module for module in _REQUIRED if not by_module.get(module, {}).get("available"))
    if missing:
        details = "; ".join(module + (": " + by_module.get(module, {}).get("error", "") if by_module.get(module, {}).get("error") else "") for module in missing)
        raise ValueError("Required model libraries are unavailable: " + details + ". Install or repair the CPU/CUDA environment first.")
    record = download(manager, component)
    active = manager.status()["active"].get(component)
    if active and active["version"] == entry["version"]:
        return {"status": "enabled", "version": entry["version"], "already_installed": True, "restart_required": False}
    manager._contract(record["manifest"], Path(record["path"]))
    return {**manager.enable(component, entry["version"]), "dependencies": dependencies,
        "scientific_evaluation": False, "upstream_revision": entry["revision"]}
