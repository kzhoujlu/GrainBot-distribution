"""Public GitHub application releases, isolated from native control updates."""
from __future__ import annotations

import json
import os
from pathlib import Path
from uuid import uuid4

from . import application_install as application
from .github_source import parse_github_source, release_api_url
from .locking import WorkspaceLock
from .updates import atomic_json, github_download, identifier

DEFAULT_URL = "https://github.com/" + application.REPOSITORY


class ApplicationUpdates:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.config = self.root / "config"
        self.state_path = self.config / "application-updates.json"
        self.record_path = self.config / "published-application.json"
        if self.config.resolve() != self.config:
            raise ValueError("Application configuration redirects outside installation")
        self.config.mkdir(parents=True, exist_ok=True)
        self.lock = WorkspaceLock(self.config / "application-updates.lock")

    def _read(self, path, default):
        if not path.resolve().is_relative_to(self.root):
            raise ValueError("Application state escapes installation")
        return json.loads(path.read_text(encoding="utf-8-sig")) if path.is_file() else default

    def _state(self):
        return self._read(self.state_path, {})

    @staticmethod
    def _source(state):
        url = state.get("source", {}).get("url") or DEFAULT_URL
        parsed = parse_github_source(url)
        return {**parsed, "url": url}

    def _bundled_version(self):
        return self._read(self.root / "release-manifest.json", {}).get("release_profile", {}).get("version", "")

    def status(self):
        state = self._state()
        source = self._source(state)
        record = self._read(self.record_path, {})
        installed = record.get("tag") or self._bundled_version()
        candidate = state.get("candidate", {})
        if candidate.get("source") != source:
            candidate = {}
        different = bool(candidate and (candidate.get("tag") != installed or
                         (record and candidate.get("repository") != record.get("repository"))))
        return {"source": source, "repository": source["repository"],
                "current_version": installed, "installed_version": installed, "version": installed,
                "candidate_version": candidate.get("tag", ""), "candidate": candidate,
                "update_available": different, "up_to_date": bool(candidate) and not different,
                "downloaded": bool(candidate) and state.get("downloaded") == candidate,
                "rollback_available": bool(state.get("history")),
                "status": state.get("status", "ready")}

    def source(self, url):
        parsed = parse_github_source(url or DEFAULT_URL)
        if not parsed["repository"]:
            parsed = parse_github_source(DEFAULT_URL)
        canonical = "https://github.com/" + parsed["repository"]
        if parsed.get("tag"):
            identifier(parsed["tag"])
            canonical += "/releases/tag/" + parsed["tag"]
        with self.lock:
            state = self._state()
            state["source"] = {**parsed, "url": canonical}
            state.pop("candidate", None)
            state.pop("downloaded", None)
            state["status"] = "source_saved"
            atomic_json(self.state_path, state)
        return self.status()

    def check(self):
        with self.lock:
            state = self._state()
            source = self._source(state)
            temporary = self.config / ("application-check-" + uuid4().hex + ".json")
            try:
                github_download(release_api_url(source), temporary, 4 * 1024**2)
                response = json.loads(temporary.read_text(encoding="utf-8"))
            finally:
                temporary.unlink(missing_ok=True)
            if response.get("draft") or response.get("prerelease"):
                raise ValueError("Only published stable application releases are eligible")
            tag = identifier(response.get("tag_name"))
            if source.get("tag") and source["tag"] != tag:
                raise ValueError("GitHub response differs from the selected release")
            known = application.catalog()
            fallback = {a["name"]: a for a in known["assets"]} if (source["repository"], tag) == (known["repository"], known["tag"]) else {}
            assets = []
            for role, prefix in application.PREFIXES.items():
                matches = [a for a in response.get("assets", []) if a.get("name", "").startswith(prefix)
                           and a.get("name", "").endswith(".zip" if role == "frontend" else "-py3-none-any.whl")]
                if len(matches) != 1:
                    raise ValueError("Application release requires one published asset for " + role)
                asset = matches[0]
                digest = asset.get("digest") or ""
                digest = digest[7:] if isinstance(digest, str) and digest.startswith("sha256:") else ""
                if not digest:
                    digest = fallback.get(asset["name"], {}).get("sha256", "")
                if not digest:
                    raise ValueError("Published application asset has no SHA256 digest; automatic installation refused")
                data = {"role": role, "name": asset["name"], "bytes": asset.get("size"),
                        "sha256": digest, "download_url": asset.get("browser_download_url")}
                if role in application.NAMESPACES:
                    data["namespace"] = application.NAMESPACES[role]
                assets.append(data)
            candidate = application.validate_release({"schema_version": 1, "repository": source["repository"],
                         "tag": tag, "release_url": response.get("html_url"), "assets": assets})
            candidate = {**candidate, "source": source}
            if state.get("candidate") != candidate:
                state.pop("downloaded", None)
            state.update(candidate=candidate, status="checked")
            atomic_json(self.state_path, state)
        return {**self.status(), "tag": tag, "release_url": candidate["release_url"]}

    def _candidate(self, state):
        candidate = state.get("candidate")
        if not candidate or candidate.get("source") != self._source(state):
            raise ValueError("Check the configured application repository again first")
        return application.validate_release(candidate)

    def download(self):
        with self.lock:
            state = self._state()
            release = self._candidate(state)
            application._cache(self.root, release, download=True)
            state.update(downloaded=release, status="downloaded")
            atomic_json(self.state_path, state)
        return {**self.status(), "tag": release["tag"], "files_retained": True}

    def _runtime(self, record):
        if record:
            return record["runtime_python"]
        portable = self.root / "runtime" / "python.exe"
        if portable.is_file():
            return str(portable)
        requested = os.environ.get("GRAINBOT_RUNTIME_PYTHON", "")
        for profile in ("cpu", "cuda128"):
            python = self.root / "environments" / profile / "Scripts" / "python.exe"
            if python.is_file() and (not requested or Path(requested).resolve() == python):
                return str(python)
        raise ValueError("Install this application's CPU, CUDA or portable runtime first")

    def install(self):
        with self.lock:
            state = self._state()
            release = self._candidate(state)
            if state.get("downloaded") != release:
                raise ValueError("Download and verify this application release first")
            application._cache(self.root, release)
            previous_record = application.verify(self.root) if self.record_path.is_file() else None
            previous_release = None
            if previous_record:
                previous_release = application.validate_release({key: previous_record[key] for key in
                    ("schema_version", "repository", "tag", "release_url", "assets")})
                if ((previous_release["repository"], previous_release["tag"]) == (release["repository"], release["tag"])
                        and previous_release != {k: v for k, v in release.items() if k != "source"}):
                    raise ValueError("Published application assets changed under an installed release tag")
            snapshot = {"release": previous_release, "record": previous_record}
            runtime = self._runtime(previous_record)
            old_state = dict(state)
            # The release identity is available to the launcher before its pointer changes.
            state["installed"] = release
            atomic_json(self.state_path, state)
            try:
                record = application.install(self.root, runtime, release)
            except Exception:
                atomic_json(self.state_path, old_state)
                if previous_release and previous_record.get("profile") != "portable":
                    application.install(self.root, runtime, previous_release)
                raise
            if ((previous_record or (self.root / "app").is_dir()) and
                    previous_release != {k: v for k, v in release.items() if k != "source"}):
                state.setdefault("history", []).append(snapshot)
            state.update(installed=release, status="installed")
            atomic_json(self.state_path, state)
        return {**self.status(), "tag": record["tag"], "restart_required": True}

    def rollback(self):
        with self.lock:
            state = self._state()
            if not state.get("history"):
                raise ValueError("No previous application installation to roll back")
            previous = state["history"][-1]
            release, record = previous["release"], previous["record"]
            if release:
                application._cache(self.root, release)
                current_record = application.verify(self.root)
                current_release = application.validate_release({key: current_record[key] for key in
                    ("schema_version", "repository", "tag", "release_url", "assets")})
                old_state = dict(state)
                state["installed"] = release
                atomic_json(self.state_path, state)
                try:
                    application.install(self.root, record["runtime_python"], release)
                except Exception:
                    atomic_json(self.state_path, old_state)
                    if current_record.get("profile") != "portable":
                        application.install(self.root, current_record["runtime_python"], current_release)
                    raise
            else:
                self.record_path.unlink(missing_ok=True)
                state.pop("installed", None)
            state["history"].pop()
            state["status"] = "rolled_back"
            atomic_json(self.state_path, state)
        return {**self.status(), "restart_required": True, "files_retained": True}
