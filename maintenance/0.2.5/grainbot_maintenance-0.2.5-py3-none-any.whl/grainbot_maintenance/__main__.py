"""Maintenance command line; importing the package performs no operation."""
import argparse
import json
import os
from pathlib import Path

from .updates import ComponentUpdates


def main():
    parser = argparse.ArgumentParser(description="GrainBot maintenance")
    parser.add_argument("command", choices=[
        "status", "source", "check", "download", "resources", "test",
        "activate", "rollback", "web", "desktop",
    ])
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--component")
    parser.add_argument("--version")
    parser.add_argument("--repository")
    parser.add_argument("--public-key")
    parser.add_argument("--accept", action="store_true")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--runtime-python", type=Path)
    parser.add_argument("--trial-image", type=Path)
    args = parser.parse_args()
    if args.command not in {"status", "web", "desktop"} and not args.component:
        parser.error("--component is required for this command")
    if args.command in {"resources", "test", "activate"} and not args.version:
        parser.error("--version is required for this command")
    if args.command == "source" and not (args.repository and args.public_key):
        parser.error("source requires --repository and --public-key")
    if args.runtime_python:
        os.environ["GRAINBOT_RUNTIME_PYTHON"] = str(args.runtime_python.resolve())
    if args.command in {"web", "desktop"}:
        from .launch import launch
        return launch(args.workspace, args.command, args.config, args.runtime_python)
    manager = ComponentUpdates(args.workspace)
    if args.trial_image:
        if args.command != "test":
            parser.error("--trial-image is only supported with test")
        manager.save_trial_image(args.component, args.version, args.trial_image.read_bytes())
    operations = {
        "status": lambda: manager.status(),
        "source": lambda: manager.source(args.component, args.repository, args.public_key),
        "check": lambda: manager.check(args.component),
        "download": lambda: manager.download(args.component),
        "resources": lambda: manager.prepare_resources(args.component, args.version),
        "test": lambda: manager.test(args.component, args.version),
        "activate": lambda: manager.activate(args.component, args.version, "accept" if args.accept else "pending"),
        "rollback": lambda: manager.rollback(args.component),
    }
    print(json.dumps(operations[args.command](), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
