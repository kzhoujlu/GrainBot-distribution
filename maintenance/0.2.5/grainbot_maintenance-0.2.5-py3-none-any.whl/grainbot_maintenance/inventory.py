"""Read declared local versions without loading models or modifying user registries."""
import importlib.util
import json
import os
import sys
from pathlib import Path
from . import __version__


def read(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    if path.stat().st_size > 128 * 1024**2:
        raise ValueError("Metadata file is too large")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def collect(manager, installation, assets=None):
    installation = Path(installation).resolve()
    workspace = manager.root.parent
    state = manager.status()
    from .application_updates import ApplicationUpdates
    application = ApplicationUpdates(installation).status()
    rows = []
    rows.append({"id": "maintenance", "kind": "software", "name": "GrainBot Maintenance", "version": __version__, "state": "installer", "path": str(installation), "managed": False})
    release = read(installation / "release-manifest.json", {})
    base = release.get("release_profile", {}).get("version", "undeclared")
    published = read(installation / "config/published-application.json", {})
    if (installation / "app").is_dir() and not published:
        for kind in ("frontend", "backend"):
            if not any(r["kind"] == kind for r in state["active"].values()):
                rows.append({"id": "bundled-"+kind, "component": "application", "mode": "application", "kind": kind, "name": "Studio "+kind, "version": base, "candidate": application.get("candidate_version", ""), "state": "bundled", "path": str(installation / "app"), "managed": True, "rollback_available": application.get("rollback_available", False), "repository": application.get("repository", "kzhoujlu/GrainBot-distribution")})
    if published:
        for kind in ("frontend", "backend"):
            if not any(r["kind"] == kind for r in state["active"].values()):
                rows.append({"id": "published-"+kind, "component": "application", "mode": "application", "kind": kind, "name": "Studio "+kind, "version": published["tag"], "candidate": application.get("candidate_version", ""), "state": "installed", "path": published[kind], "repository": application.get("repository", published["repository"]), "rollback_available": application.get("rollback_available", False), "managed": True})
    assets = Path(assets) if assets else installation / "app/packages/matmorph/assets/installed" if (installation / "app").is_dir() else workspace / "assets"
    settings = read(workspace / "dataset_workspace.json", {})
    dataset_roots = {assets / "datasets", workspace / "datasets"}
    if settings.get("path"):
        dataset_roots.add(Path(settings["path"]).resolve())
    model_roots = {assets / "models", workspace / "models", *[p / "models" for p in dataset_roots]}
    seen = set()
    warnings = []
    for root in model_roots:
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("*.json"), key=lambda p: (p.name != "model.json", str(p))):
            if path.name not in {"model.json", "bundle.json", "official-model.json"}:
                continue
            try:
                data = read(path)
                identity = str(path.parent.resolve())
                if identity in seen or (path.name == "bundle.json" and str(path.parent.parent.resolve()) in seen):
                    continue
                seen.add(identity)
                rows.append({"id": str(data.get("id", data.get("bundle_id", path.parent.name))), "name": str(data.get("name", data.get("bundle_id", path.parent.name))), "kind": "model", "version": str(data.get("version", "undeclared")), "state": "installed", "path": identity, "managed": False})
            except (OSError, ValueError, TypeError) as error:
                warnings.append(str(path)+": "+str(error))
    for root in dataset_roots:
        try:
            for data in read(root / "registry.json", {}).get("datasets", []):
                if data.get("archived"):
                    continue
                identity = str(root)+":"+data["id"]
                if identity in seen:
                    continue
                seen.add(identity)
                version = data.get("version")
                manifest = read(data.get("manifest_path", "") or root / "missing.json", {})
                version = version or manifest.get("version", "undeclared")
                rows.append({"id": data["id"], "name": data.get("name", data["id"]), "kind": "dataset", "version": str(version), "state": "registered", "path": str(data.get("root_path", root)), "samples": len(data.get("samples", [])), "managed": False})
        except (OSError, ValueError, TypeError) as error:
            warnings.append(str(root)+": "+str(error))
    for component, source in state["sources"].items():
        last = next((event for event in reversed(manager._read("history.json", [])) if event["component"] == component), None)
        rollback_available = bool(last and last["action"] in {"activate", "disable"})
        records = [r for r in state["staged"].values() if r["manifest"]["component"] == component]
        active = state["active"].get(component)
        kind = source.get("kind") or (active or {}).get("kind") or (records[-1]["manifest"]["kind"] if records else "software")
        if not records:
            rows.append({"id": component, "component": component, "name": component, "kind": kind, "version": "", "state": "source", "managed": True, "repository": source.get("repository", ""), "candidate": state.get("candidates", {}).get(component, {}).get("tag", "")})
        for record in records:
            manifest = record["manifest"]
            rows.append({"id": component+":"+manifest["version"], "component": component, "name": manifest.get("name", component), "kind": manifest["kind"], "version": manifest["version"], "state": record["status"], "review": record["review"], "active": bool(active and active["version"] == manifest["version"]), "rollback_available": rollback_available, "managed": True, "path": record["path"], "repository": source.get("repository", ""), "candidate": state.get("candidates", {}).get(component, {}).get("tag", ""), "trial": record.get("trial", {}), "has_trial_image": bool(record.get("trial_image"))})
    from .third_party import catalog_rows, libraries
    defaults = catalog_rows(manager)
    ids = {row["component"] for row in defaults}
    rows = [row for row in rows if row.get("component") not in ids]+defaults
    try:
        report = libraries(os.environ.get("GRAINBOT_RUNTIME_PYTHON", sys.executable))
        rows.extend({"id": "library:"+item["module"], "kind": "software", "mode": "library", "name": item["name"], "version": item["version"] or "undeclared", "state": "installed" if item["available"] else "missing", "repository": "Official Python package source", "managed": False} for item in report["libraries"])
    except (ValueError, OSError) as error:
        warnings.append(str(error))
    return {"rows": rows, "sources": state["sources"], "application_source": application.get("source", {"url":"https://github.com/kzhoujlu/GrainBot-distribution"}), "warnings": warnings, "signature_support": importlib.util.find_spec("cryptography") is not None, "workspace": str(workspace), "automatic_activation": False}
