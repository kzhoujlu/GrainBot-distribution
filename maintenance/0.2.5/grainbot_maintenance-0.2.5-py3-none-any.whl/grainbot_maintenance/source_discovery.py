"""Inspect public release contents so source setup does not require component IDs."""
import json
import hashlib
from pathlib import Path
from tempfile import TemporaryDirectory
from .github_source import parse_github_source, release_api_url
from .updates import github_download, identifier


def inspect_source(url, workspace):
    source = parse_github_source(url)
    directory = Path(workspace) / "updates"
    directory.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="inspect-", dir=directory) as temporary:
        folder = Path(temporary)
        github_download(release_api_url(source), folder / "release.json", 4*1024**2)
        release = json.loads((folder / "release.json").read_text(encoding="utf-8"))
        if release.get("draft") or release.get("prerelease"):
            raise ValueError("Choose a published stable release")
        from .release_metadata import release_files
        metadata = release_files(release, source["repository"], folder)
        assets = metadata["assets"]
        names = list(assets)
        options = []
        roles = {"grainbot_maintenance-": ".whl", "grainbot_studio_app-": ".whl", "matmorph-": ".whl", "grainbot_frontend-": ".zip"}
        if all(any(name.startswith(prefix) and name.endswith(suffix) for name in names) for prefix, suffix in roles.items()):
            options.append({"component": "application", "kind": "application", "name": "GrainBot application", "version": release["tag_name"]})
        for name, url in assets.items():
            if not name.endswith(".manifest.json"):
                continue
            component = name[:-len(".manifest.json")]
            identifier(component)
            if not url.startswith(f"https://github.com/{source['repository']}/releases/download/") and not (name in metadata["hashes"] and url.startswith(f"https://raw.githubusercontent.com/{source['repository']}/{metadata['revision']}/")):
                raise ValueError("Release manifest must belong to the configured repository")
            file = folder / (component+".json")
            github_download(url, file, 32*1024**2)
            if name in metadata["hashes"] and hashlib.sha256(file.read_bytes()).hexdigest() != metadata["hashes"][name]:
                raise ValueError("Component metadata SHA256 mismatch")
            manifest = json.loads(file.read_text(encoding="utf-8"))
            if manifest.get("component") != component or manifest.get("kind") not in {"model", "dataset", "frontend", "backend"}:
                raise ValueError("Unsupported release component")
            options.append({"component": component, "kind": manifest["kind"], "name": manifest.get("name", component), "version": manifest["version"]})
        if not options:
            raise ValueError("This release has no installable application or component manifest")
        return {"repository": source["repository"], "tag": release["tag_name"], "options": options}
