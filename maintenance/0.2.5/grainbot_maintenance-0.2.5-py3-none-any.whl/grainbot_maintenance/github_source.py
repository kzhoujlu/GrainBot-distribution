"""Normalize explicit public GitHub repositories and fixed release links."""
from __future__ import annotations

import re
from urllib.parse import quote, unquote, urlsplit

REPOSITORY = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


def parse_github_source(value: str) -> dict:
    """Accept owner/repo or a GitHub repository/release URL, without credentials."""
    if not isinstance(value, str):
        raise ValueError("Use a public GitHub repository or release link")
    value = value.strip()
    if not value:
        return {"repository": "", "tag": None}
    tag = None
    if "://" in value:
        url = urlsplit(value)
        if (url.scheme != "https" or url.hostname != "github.com" or url.username
                or url.password or url.port not in {None, 443} or url.query or url.fragment):
            raise ValueError("Source must be a public github.com HTTPS repository or release link")
        parts = url.path.strip("/").split("/")
        if len(parts) < 2:
            raise ValueError("GitHub source must identify owner/repo")
        repository = "/".join(parts[:2])
        tail = parts[2:]
        if tail not in ([], ["releases"], ["releases", "latest"]):
            if len(tail) < 3 or tail[:2] != ["releases", "tag"]:
                raise ValueError("Use a repository, releases/latest or releases/tag/TAG link")
            tag = unquote("/".join(tail[2:]))
            if not tag or "\\" in tag or any(ord(c) < 32 or ord(c) == 127 for c in tag):
                raise ValueError("Invalid GitHub release tag")
    else:
        repository = value.rstrip("/")
    if not REPOSITORY.fullmatch(repository) or any(p in {".", ".."} for p in repository.split("/")):
        raise ValueError("GitHub source must identify owner/repo")
    return {"repository": repository, "tag": tag}


def release_api_url(source: dict) -> str:
    """Fixed links keep their tag; repository links resolve the latest stable release."""
    repository = source["repository"]
    if not repository:
        raise ValueError("Configure a GitHub repository or release link first")
    suffix = "tags/" + quote(source["tag"], safe="") if source.get("tag") else "latest"
    return f"https://api.github.com/repos/{repository}/releases/{suffix}"
