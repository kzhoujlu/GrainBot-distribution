"""Launch accepted components without importing scientific code into maintenance."""
import os
from pathlib import Path
import subprocess
import sys

from .updates import ComponentUpdates


def launch(workspace, mode="web", config=None, runtime_python=None):
    manager = ComponentUpdates(workspace)
    active = manager.status()["active"]
    selected = {record["kind"]: record for record in active.values()
                if record["kind"] in {"frontend", "backend"}}
    locations = {}
    installation = os.environ.get("GRAINBOT_INSTALLATION_ROOT")
    published = {}
    if installation and (Path(installation) / "config/published-application.json").is_file():
        from .application_install import verify
        published = verify(Path(installation))
    for kind in ("frontend", "backend"):
        if kind in selected:
            locations[kind] = str(Path(selected[kind]["path"]) / "payload")
        else:
            fallback = published.get(kind) or os.environ.get("GRAINBOT_BUNDLED_"+kind.upper())
            if not fallback or not Path(fallback).is_dir():
                raise ValueError("Install the application or enable frontend and backend components first")
            locations[kind] = fallback
    for record in active.values():
        manager._verify_record(record)
    environment = os.environ.copy()
    environment.update({
        "GRAINBOT_WORKSPACE": str(Path(workspace).resolve()),
        "GRAINBOT_FRONTEND_DIST": locations["frontend"],
        "GRAINBOT_BACKEND_SRC": locations["backend"],
        "GRAINBOT_COMPONENT_START": "1",
    })
    environment.setdefault("MATMORPH_ASSETS_ROOT", str(Path(workspace).resolve() / "assets"))
    executable = str(runtime_python or environment.get("GRAINBOT_RUNTIME_PYTHON", sys.executable))
    command = [executable, str(Path(__file__).with_name("runner.py")), mode]
    if config:
        command.extend(["--config", str(Path(config).resolve())])
    return subprocess.call(command, env=environment)
